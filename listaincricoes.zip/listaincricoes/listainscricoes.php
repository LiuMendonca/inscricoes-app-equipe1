<?php

$inscricoes = [

    [
        "id" => 1,
        "candidato" => "Maria Silva",
        "data" => "2026-04-29",
        "vaga" => "Docente",
        "edital" => "15/2026",
        "status" => "Pendente"
    ],

    [
        "id" => 2,
        "candidato" => "João Costa",
        "data" => "2026-04-28",
        "vaga" => "Técnico",
        "edital" => "20/2026",
        "status" => "Aprovado"
    ],

    [
        "id" => 3,
        "candidato" => "Ana Souza",
        "data" => "2026-04-27",
        "vaga" => "Docente",
        "edital" => "44/2026",
        "status" => "Rejeitado"
    ],

    [
        "id" => 4,
        "candidato" => "Carlos Lima",
        "data" => "2026-04-25",
        "vaga" => "Coordenador",
        "edital" => "44/2026",
        "status" => "Devolvido"
    ],

    [
        "id" => 5,
        "candidato" => "Fernanda Alves",
        "data" => "2026-04-20",
        "vaga" => "Docente",
        "edital" => "10/2026",
        "status" => "Pendente"
    ]
];

/* FILTROS */

$editalFiltro = $_GET['edital'] ?? '';
$statusFiltro = $_GET['status'] ?? '';
$dataFiltro   = $_GET['data'] ?? '';

$resultado = [];

foreach($inscricoes as $item){

    $mostrar = true;

    if($editalFiltro != '' &&
       stripos($item['edital'], $editalFiltro) === false){
        $mostrar = false;
    }

    if($statusFiltro != '' &&
       $item['status'] != $statusFiltro){
        $mostrar = false;
    }

    if($dataFiltro != '' &&
       $item['data'] != $dataFiltro){
        $mostrar = false;
    }

    if($mostrar){
        $resultado[] = $item;
    }
}

/* PAGINAÇÃO */

$porPagina = 3;

$total = count($resultado);

$paginaAtual = $_GET['pagina'] ?? 1;

$inicio = ($paginaAtual - 1) * $porPagina;

$dadosPagina = array_slice($resultado, $inicio, $porPagina);

foreach($dadosPagina as $item){

    $classe = strtolower($item['status']);

    echo "
    <tr>

        <td>{$item['candidato']}</td>

        <td>
            ".date('d/m/Y', strtotime($item['data']))."
        </td>

        <td>{$item['vaga']}</td>

        <td>{$item['edital']}</td>

        <td>
            <span class='status $classe'>
                {$item['status']}
            </span>
        </td>

        <td>

            <div class='acoes'>

                <a class='btn-visualizar'
                   href='visualizar.php?id={$item['id']}'>
                   <i class='fa-solid fa-eye'></i>
                </a>

            </div>

        </td>

    </tr>
    ";
}

/* PAGINAÇÃO */

$totalPaginas = ceil($total / $porPagina);

echo "
<tr>
<td colspan='6'>

<div class='paginacao'>
";

for($i = 1; $i <= $totalPaginas; $i++){

    echo "
    <a href='?pagina=$i'>
        $i
    </a>
    ";
}

echo "
</div>

</td>
</tr>
";
?>