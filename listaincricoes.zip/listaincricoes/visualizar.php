<?php

$id = $_GET['id'] ?? 0;

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Visualizar candidatura</title>

    <style>

        body{
            font-family:Arial;
            background:#f2f2f2;
            padding:40px;
        }

        .card{
            background:white;
            padding:30px;
            border-radius:10px;
            max-width:600px;
            margin:auto;
        }

        h1{
            margin-bottom:20px;
        }

        p{
            margin:10px 0;
        }

        a{
            display:inline-block;
            margin-top:20px;
            text-decoration:none;
            background:#3bb54a;
            color:white;
            padding:10px 20px;
            border-radius:8px;
        }

    </style>

</head>
<body>

<div class="card">

    <h1>Candidatura #<?php echo $id; ?></h1>

    <p><strong>Status:</strong> Em análise</p>

    <p><strong>Descrição:</strong>
    Dados completos da candidatura.</p>

    <a href="index.html">
        Voltar
    </a>

</div>

</body>
</html>