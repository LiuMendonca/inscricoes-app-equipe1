<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Inscrições</title>

    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="listainscricoes.php">

    <!-- Font Awesome -->
    <link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>

<div class="container">

    <!-- MENU -->
    <aside class="sidebar">

        <div class="logo">

            
        </div>

        <nav class="menu">

            <a href="#" class="menu-item">
                <i class="fa-solid fa-house"></i>
                <span>Início</span>
            </a>

            <a href="#" class="menu-item">
                <i class="fa-solid fa-user"></i>
                <span>Meu perfil</span>
            </a>

            <a href="#" class="menu-item active">
                <i class="fa-solid fa-list"></i>
                <span>Minhas inscrições</span>
            </a>

        </nav>

        <div class="logout">
            <a href="#">
                <i class="fa-solid fa-right-from-bracket"></i>
                <span>Sair</span>
            </a>
        </div>

    </aside>

    <!-- CONTEÚDO -->
    <main class="conteudo">

        <div class="titulo">
            <h1>MINHAS INSCRIÇÕES</h1>
            <p>Acompanhe o status das candidaturas</p>
        </div>

        <!-- FILTROS -->
        <div class="filtros">

            <form method="GET" action="listainscricoes.php">

                <div class="campo">
                    <label>Edital</label>
                    <input type="text" name="edital" placeholder="Digite o edital">
                </div>

                <div class="campo">
                    <label>Status</label>

                    <select name="status">
                        <option value="">Todos</option>
                        <option value="Pendente">Pendente</option>
                        <option value="Aprovado">Aprovado</option>
                        <option value="Rejeitado">Rejeitado</option>
                        <option value="Devolvido">Devolvido</option>
                    </select>
                </div>

                <div class="campo">
                    <label>Data</label>
                    <input type="date" name="data">
                </div>

                <button type="submit" class="btn-filtrar">
                    <i class="fa-solid fa-filter"></i>
                    Filtrar
                </button>

            </form>

        </div>

        <!-- TABELA -->
        <div class="card-tabela">

            <table>

                <thead>
                    <tr>
                        <th>Candidato</th>
                        <th>Data inscrição</th>
                        <th>Vaga</th>
                        <th>Edital</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>

                <tbody>

                    <?php include 'listainscricoes.php'; ?>

                </tbody>

            </table>

        </div>

    </main>

</div>

</body>
</html>